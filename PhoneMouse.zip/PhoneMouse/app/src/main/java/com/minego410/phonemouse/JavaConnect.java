package com.minego410.phonemouse;

import android.util.Log;

import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
public class JavaConnect {


    public static void SendHello(){
        Socket socket;
        try{
            InetAddress serverAddr = InetAddress.getByName("10.7.102.148");
            Log.d("We tried","Message sent");
            socket = new Socket(serverAddr,5000);
            PrintWriter writer = new PrintWriter(socket.getOutputStream());
            writer.print("Hello");
            writer.flush();
            writer.close();
            socket.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }



}
