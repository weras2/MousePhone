package com.minego410.phonemouse;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import android.util.Log;

public class MainActivity extends Activity implements SensorEventListener {
    private TextView txt;
    private Button b;


    //Accelerometer varibles
    private SensorManager sensorManager;
    Sensor accelerometer;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b = (Button)findViewById(R.id.button1);
        txt = (TextView)findViewById(R.id.textView1);

        //Accelerometer
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager.registerListener(MainActivity.this,accelerometer,SensorManager.SENSOR_DELAY_NORMAL);







        //Connection
        b.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Thread connectionThread = new Thread(new Runnable() {
                    @Override
                    public void run(){

                        connectSocket("1");
                    }
                });

                connectionThread.start();


            }
        });
    }

    //More accelerometer stuff

    public double Magnitude2(float[] arr1,float[] arr2){
        return Math.sqrt(Math.pow(arr1[0]-arr2[1],2) + Math.pow(arr1[0]-arr2[1],2));
    }

    public double Magnitude(float[] arr1){
        return Math.sqrt(Math.pow(arr1[0],2)+Math.pow(arr1[1],2));
    }


    @Override
    public void onAccuracyChanged(Sensor sensor,int i){
        //Expand on this in the future
    }


    float[] tmpVal = {0,0};
    float[] mult = {0,0};
    float[] gravity = {0,0,0};
    float[] linear_acceleration = {0,0,0};
    @Override
    public void onSensorChanged(final SensorEvent sensorEvent){


        final float alpha = 0.8f;

        gravity[0] = alpha * gravity[0] + (1 - alpha) * sensorEvent.values[0];
        gravity[1] = alpha * gravity[1] + (1 - alpha) * sensorEvent.values[1];
        gravity[2] = alpha * gravity[2] + (1 - alpha) * sensorEvent.values[2];

        linear_acceleration[0] = sensorEvent.values[0] - gravity[0];
        linear_acceleration[1] = sensorEvent.values[1] - gravity[1];
        linear_acceleration[2] = sensorEvent.values[2] - gravity[2];

        Log.d("LOOk", " | : " + linear_acceleration[0] + " | " + linear_acceleration[1] + " | " + linear_acceleration[2]);

        if(Magnitude2(tmpVal,sensorEvent.values) > 1) {
            //Log.d("LOOK", "onSensorChanged: X: " + sensorEvent.values[0] + " Y: " + sensorEvent.values[1] + " Z: " + sensorEvent.values[2]);

            Thread connectionThread = new Thread(new Runnable() {
                @Override
                public void run(){

                    mult[0] += -23*linear_acceleration[0]/(float)Magnitude(linear_acceleration);
                    mult[1] += -23*linear_acceleration[1]/(float)Magnitude(linear_acceleration);

                    connectSocket(ArrayToString(mult));
                }
            });

            connectionThread.start();
            tmpVal[0] = sensorEvent.values[0];
            tmpVal[1] = sensorEvent.values[1];

        }else{
            tmpVal[0] =sensorEvent.values[0];
            tmpVal[1] = sensorEvent.values[1];
        }
    }






        private String ArrayToString(float[] array){
        return "" + array[0] + "a" + array[1];
    }

    private void connectSocket(String msg){

        try {
            InetAddress serverAddr = InetAddress.getByName("10.7.102.148");
            Log.d("TCP", "C: Connecting...");
        Socket socket = new Socket(serverAddr, 11000);

            String message = msg;
            PrintWriter out = null;
            BufferedReader in = null;

            try {
                Log.d("TCP", "C: Sending: '" + message + "'");
                out = new PrintWriter( new BufferedWriter( new OutputStreamWriter(socket.getOutputStream())),true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                out.println(message);
                while ((in.readLine()) != null) {
                    txt.append(in.readLine());
                }

                Log.d("TCP", "C: Sent.");
                Log.d("TCP", "C: Done.");

            } catch(Exception e) {
                Log.e("TCP", "S: Error", e);
            } finally {
                out.flush();
                socket.close();
            }

        } catch (UnknownHostException e) {
            // TODO Auto-generated catch block
            Log.e("TCP", "C: UnknownHostException", e);
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            Log.e("TCP", "C: IOException", e);
            e.printStackTrace();
        }
    }
}